from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('callculadora.html')

@app.route('/calculate', methods=['POST'])
def calculate():
    data = request.get_json()
    weight = float(data['weight'])
    height = float(data['height'])
    age = int(data['age'])
    gender = data['gender']
    activity = data['activity']

    # Ideal weight (Devine formula)
    if gender == 'male':
        ideal_weight = 50 + 0.9 * (height - 150)
    else:
        ideal_weight = 45 + 0.9 * (height - 150)

    # BMR (Harris-Benedict)
    if gender == 'male':
        bmr = 88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * age)
    else:
        bmr = 447.593 + (9.247 * weight) + (3.098 * height) - (4.330 * age)

    # Activity factor
    activity_factors = {
        'sedentary': 1.2,
        'light': 1.375,
        'moderate': 1.55,
        'active': 1.725,
        'very_active': 1.9
    }
    tdee = bmr * activity_factors[activity]

    # Macronutrients (example: 40% carbs, 30% protein, 30% fat)
    carbs_cal = tdee * 0.4
    protein_cal = tdee * 0.3
    fat_cal = tdee * 0.3
    carbs_g = carbs_cal / 4
    protein_g = protein_cal / 4
    fat_g = fat_cal / 9

    # Micronutrients (RDA example)
    micronutrients = {
        'Vitamin A': '900 mcg',
        'Vitamin C': '90 mg',
        'Calcium': '1000 mg',
        'Iron': '18 mg',
        'Potassium': '4700 mg'
    }

    # Glycemic index (placeholder, assume average meal GI)
    gi = 50  # Example

    return jsonify({
        'ideal_weight': round(ideal_weight, 2),
        'total_calories': round(tdee, 2),
        'macronutrients': {
            'carbs': round(carbs_g, 2),
            'protein': round(protein_g, 2),
            'fat': round(fat_g, 2)
        },
        'micronutrients': micronutrients,
        'glycemic_index': gi
    })

if __name__ == '__main__':
    app.run(debug=True)
